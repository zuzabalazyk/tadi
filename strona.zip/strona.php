<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>CURRICULUM VITAE </title>
    <link rel="stylesheet" href="style1.css">
</head>
<body>

<header>
    <h1>Zuzanna Maria Bałażyk</h1>
</header>

<section id="dane">
    <h3>Cel zawodowy:</h3>
    <p> Moim celem zawodowym jest ambitna praca, umożliwiająca doskonalenie i podnoszenie kwalifikacji <br>
    oraz bezpośrednie i pośrednie kreowanie wizerunku firmy </p>
    <ul>

</ul>
</section>

<section id="flexiak">

<section id="lewy">
    <h2>Umiejętności</h2>
    <table>
        <tr>
            <td>Wystąpienia publiczne</td>
        </tr>
        <tr>
            <td>Umiejętności komunikacyjne</td>
        </tr>
        <tr>
            <td>Umiejętności zarządzania zespołem (+10 osób) </td>
        </tr>
        <tr>
            <td> Biegłe posługiwanie się jezykiem angielskim</td>
        </tr>
        <tr>
            <td> Podstawowa znajomość języka niemieckiego</td>
        </tr>
    </table>
    </section>
<section id="srodkowy">
    <h2>Doświadczenie</h2>
    <p> 07.2019- 07.2020    Bezpośrednia dystrybucja materiałów promocyjnych </p>
    <p> 01.2019- 05.2021    Wiceprzewodnicząca Młodzieżowej Rady miasta Poznania </p>
    <p> 01.2021- 07.2022    Pracownik Produkcji w firmie EFAWA- monter zaworów </p>
</section>
<section id="prawy">
    <h2>Moje dane</h2>
    <p> Data urodzenia: 15.10.2004 </p>
    <p> Miejsce zamieszkania: Luboń </p>
    <a href="mailto:zuzabalazyk@icloud.com">napisz do mnie maila :) </a>
    <p>telefon: 502479450</p>
</section>

</section>

<footer>
    <p>Stronę wykonała Zuzanna Bałażyk</p>
</footer>

</body>
</html>